<script>
$(document).ready(function(){
    $('#profileForm').submit(function(event){
        event.preventDefault(); 

        var formData = {
            firstname: $('input[name="fname"]').val(),
            lastname: $('input[name="lname"]').val(),
            age: $('input[name="age"]').val(),
            dob: $('input[name="age"]').val(),
            contact: $('input[name="contact"]').val()
        };

        $.ajax({
            type: 'POST',
            url: 'php/profile.php',
            data: formData,
            dataType: 'json',
            encode: true,
            success: function(response) {
                if (response.status === 'success') {
                    alert(response.message);
                } else {
                    alert(response.message);
                }
            },
            error: function() {
                alert('Error updating profile.');
            }
        });
    })
})
</script>
