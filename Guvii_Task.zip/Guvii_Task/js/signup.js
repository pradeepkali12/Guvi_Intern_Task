$(document).ready(function() {

    $('#email').on('blur', function() {
        var email = $(this).val();

        if (email.length > 0) {
            $.ajax({
                type: 'POST',
                url: 'php/signup.php',
                data: { email: email },
                dataType: 'json',
                success: function(response) {
                    if (response.exists) {
                        $('#emailError').text('Email already exists. Please use a different email.');
                    } else {
                        $('#emailError').text('');
                    }
                },
                error: function() {
                    $('#emailError').text('An error occurred while checking the email.');
                }
            });
        }
    });

    $('#signupForm').on('submit', function(event) {
        event.preventDefault();

        var formData = {
            fname: $('input[name="fname"]').val(),
            lname: $('input[name="lname"]').val(),
            email: $('input[name="email"]').val(),
            password: $('input[name="password"]').val()
        };

        var passwordPattern = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/;
        if (!passwordPattern.test(formData.password)) {
            $('#passwordError').text(' Atleast 8 characters and include one special character.');
            return;
        } else {
            $('#passwordError').text('');
        }

        $.ajax({
            type: 'POST',
            url: 'php/signup.php',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    alert(response.message);
                    window.location.href = 'login.html';
                } else if (response.status === 'error') {
                    alert(response.message);
                }
            },
            error: function() {
                alert('An error occurred while processing your request.');
            }
        });
    });
});
