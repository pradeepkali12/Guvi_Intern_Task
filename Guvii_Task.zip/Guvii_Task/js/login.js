$(document).ready(function() {
    // Check if email exists and validate password format on blur
    $('#email').on('blur', function() {
        var email = $(this).val();

        if (email.length > 0) {
            $.ajax({
                type: 'POST',
                url: 'php/login.php',
                data: { email: email },
                dataType: 'json',
                success: function(response) {
                    if (!response.exists) {
                        $('#emailError').text('Email does not exist. Please sign up.');
                    } else {
                        $('#emailError').text('');
                    }
                },
                error: function() {
                    $('#emailError').text('An error occurred while checking the email.');
                }
            });
        }
    });

    // Validate form on submit
    $('#loginForm').on('submit', function(event) {
        event.preventDefault();

        var formData = {
            email: $('input[name="email"]').val(),
            password: $('input[name="password"]').val()
        };

        $.ajax({
            type: 'POST',
            url: 'php/login.php',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    alert(response.message);
                    window.location.href = 'profile.html';
                } else if (response.status === 'error') {
                    alert(response.message);
                }
            },
            error: function() {
                alert('An error occurred while processing your request.');
            }
        });
    });
});
