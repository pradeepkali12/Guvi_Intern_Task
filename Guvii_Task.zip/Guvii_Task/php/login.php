<?php
session_start();


$host = "localhost";
$dbname = "internship";
$username = "root";
$password = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

require '../vendor/autoload.php';

$redis = new Predis\Client([
    'scheme' => 'tcp',
    'host'   => '127.0.0.1',
    'port'   => 6379,
]);

try {
    $redis->ping();
} catch (Exception $e) {
    echo "Couldn't connect to Redis. Is the server running?";
    exit;
}


$email = $_POST['email'];
$password = $_POST['password'];


$sessionKey = "user:session:" . md5($email);
if ($redis->exists($sessionKey)) {
    echo json_encode(array("status" => "success"));
    die;
}


$stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND password = ?");
$stmt->execute([$email, $password]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user) {
    
    $redis->set($sessionKey, json_encode($user));
    $redis->expire($sessionKey, 3600); 
    $_SESSION['email'] = $email;
    $response['status'] = 'error';
    die;
} else {
    $response['status'] = 'error';
    $response['message'] = 'Invalid request method.';
}

?>
