<?php
require '../vendor/autoload.php';

$redis = new Predis\Client([
    'scheme' => 'tcp',
    'host'   => '127.0.0.1',
    'port'   => 6379,
]);

try {
    $redis->ping();
} catch (Exception $e) {
    echo "Couldn't connect to Redis. Is the server running?";
    exit;
}
?>