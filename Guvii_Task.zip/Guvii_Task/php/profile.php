<?php
session_start();

require '..vendor/autoload.php';

use MongoDB\Client;

$host = "localhost";
$dbname = "internship";
$username = "root";
$password = "";

$mongoHost = 'localhost';
$mongoPort = 27017;
$mongoDatabase = 'internship';
$mongoCollection = 'users';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $age = $_POST['age'];
    $dob = $_POST['dob'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];

    $stmt = $pdo->prepare("INSERT users SET fname=?, lname=?, age=?, dob=?, contact=? WHERE email=?");
    $stmt->execute([$fname, $lname, $age, $dob, $contact, $email]);

    if ($stmt->rowCount() > 0) {
        $mongoClient = new Client("mongodb://$mongoHost:$mongoPort");

        $mongoDb = $mongoClient->$mongoDatabase;
        $mongoCollection = $mongoDb->$mongoCollection;

    
        $mongoCollection->updateOne(
            ['email' => $email],
            ['$set' => [
                'fname' => $fname,
                'lname' => $lname,
                'age' => $age,
                'dob' => $dob,
                'contact' => $contact
            ]]
        );

        echo "Profile updated successfully";
    } else {
        echo "Error updating profile: No rows affected";
    }
}
?>
