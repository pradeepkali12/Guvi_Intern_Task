<?php
session_start();

$host = "localhost";
$dbname = "internship";
$username = "root";
$password = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'ERROR connecting to the database: ' . $e->getMessage();
    exit();
}

require '../vendor/autoload.php';

$redis = new Predis\Client([
    'scheme' => 'tcp',
    'host'   => '127.0.0.1',
    'port'   => 6379,
]);

try {
    $redis->ping();
} catch (Exception $e) {
    echo "Couldn't connect to Redis. Is the server running?";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    try {
    
        $sessionKey = "user:session:" . md5($email);
        if ($redis->exists($sessionKey)) {
            $response['status'] = 'success';
            $response['message'] = 'Logged in successfully';
            $response['redirect'] = 'profile.html';
            echo json_encode($response);
            exit();
        }

    
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND password = ?");
        $stmt->execute([$email, $password]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            
            $redis->set($sessionKey, json_encode($user));
            $redis->expire($sessionKey, 3600); 

            $_SESSION['email'] = $email;

            $response['status'] = 'success';
            $response['message'] = 'Logged in successfully';
            $response['redirect'] = 'profile.html';
        } else {
            $response['status'] = 'error';
            $response['message'] = 'Invalid email or password.';
        }
    } catch (PDOException $e) {
        $response['status'] = 'error';
        $response['message'] = 'Error: ' . $e->getMessage();
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'Invalid request method.';
}

echo json_encode($response);
?>
