<?php
require '../vendor/autoload.php'; // Ensure you've installed Predis via Composer or use the PHP Redis extension
$redis = new Predis\Client();
$redis->connect('127.0.0.1', 6379); 

if (!$redis->ping()) {
    die("Failed to connect to Redis server");
}
?>
