<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'redis.php';
require '../vendor/autoload.php';

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "guvi_task";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['email']) && isset($_POST['password'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    $stmt = $conn->prepare("SELECT password, name FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($hashed_password, $name);
    $stmt->fetch();

    if (password_verify($password, $hashed_password)) {
        $session_token = bin2hex(random_bytes(32));

        $redis->set($session_token, $email);
        $redis->expire($session_token, 3600);

        $profilekey = "profiles:$email";
        $redis->hmset($profilekey, [
            'name' => $name
        ]);

        echo json_encode(['status' => 'success', 'session_token' => $session_token]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid credentials']);
    }

    $stmt->close();
}

$conn->close();
?>
