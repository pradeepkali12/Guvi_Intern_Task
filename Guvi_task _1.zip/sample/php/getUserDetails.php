<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'redis.php';
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "guvi_task";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['session_token'])) {
    $session_token = filter_var($_POST['session_token'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $email = $redis->get($session_token);
    $profilekey = "profiles:$email";

    if ($email) {
        $profile_data = $redis->hgetall($profilekey);
        if ($profile_data) {
            echo json_encode(['status' => 'success', 'profile' => $profile_data]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Profile not found']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid session']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'No session token provided']);
}
?>
