<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'redis.php'; 
require '../vendor/autoload.php'; 

$client = new MongoDB\Client("mongodb://localhost:27017");
$collection = $client->guvi_task->profiles;

if (isset($_POST['session_token'])) {
    $session_token = filter_var($_POST['session_token'] );
    $email = $redis->get($session_token);
    $profilekey = "profiles:$email";

    if ($email) {
        $age = filter_var($_POST['age'] );
        $dob = filter_var($_POST['dob']);
        $contact = filter_var($_POST['contact']);

        // Update MongoDB
        $result = $collection->updateOne(
            ['email' => $email],
            ['$set' => ['age' => $age, 'dob' => $dob, 'contact' => $contact]],
            ['upsert' => true]
        );

        // Update Redis
        $redis->hmset($profilekey, [
            'age' => $age,
            'dob' => $dob,
            'contact' => $contact
        ]);

        if ($result->getModifiedCount() > 0 || $result->getUpsertedCount() > 0) {
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => '']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid session']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'No session token provided']);
}
?>
