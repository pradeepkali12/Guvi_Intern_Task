$(document).ready(function() {
    $("#email").on("blur", function() {
        let email = $(this).val();
        if (email.length > 0) {
            $.ajax({
                url: 'php/check.php',
                type: 'POST',
                data: {email: email},
                success: function(response) {
                    if (response === 'exists') {
                        $("#emailHelp").text("Email already exists").css("color", "red");
                    } else {
                        $("#emailHelp").text("").css("color", "");
                    }
                }
            });
        }
    });

    $("#signupForm").on("submit", function(e) {
        e.preventDefault();
        let password = $("#password").val();
        let passwordHelp = $("#passwordHelp");

        if (password.length < 8 || !/\d/.test(password) || !/[a-zA-Z]/.test(password)) {
            passwordHelp.text("Password must be at least 8 characters long and contain both letters and numbers.").css("color", "red");
        } else {
            passwordHelp.text("");
            $.ajax({
                url: 'php/signup.php',
                type: 'POST',
                data: $(this).serialize(),
                success: function(response) {
                    if (response === 'success') {
                        alert("Registration successful!");
                        window.location.href = 'login.html';
                    } else {
                        alert("Registration failed. Try again.");
                    }
                }
            });
        }
    });
});
