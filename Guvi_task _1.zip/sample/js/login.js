$(document).ready(function() {
    // Login Form
    $("#loginForm").on("submit", function(e) {
        e.preventDefault();
        $.ajax({
            url: 'php/login.php',
            type: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                let res;
                if (isValidJson(response)) {
                    res = JSON.parse(response);
                    if (res.status === 'success') {
                        localStorage.setItem('session_token', res.session_token);
                        alert("Login successful!");
                        window.location.href = 'profile.html';
                    } else {
                        alert(res.message || "Invalid login credentials. Try again.");
                    }
                } else {
                    console.error("Invalid JSON response:", response);
                    alert("An error occurred during login. Please try again.");
                }
            }
        });
    });

    // Profile Page
    if (window.location.pathname.endsWith("profile.html")) {
        let sessionToken = localStorage.getItem('session_token');

        if (!sessionToken) {
            window.location.href = 'login.html';
        } else {
            $.ajax({
                url: 'php/getUserDetails.php',
                type: 'POST',
                data: { session_token: sessionToken },
                success: function(response) {
                    let res;
                    if (isValidJson(response)) {
                        res = JSON.parse(response);
                        if (res.status === 'success') {
                            let profile = res.profile;
                            $("#welcomeMessage").text(`Welcome to Guvi, ${profile.name}`);
                        } else {
                            alert(res.message || "An error occurred. Please log in again.");
                            window.location.href = 'login.html';
                        }
                    } else {
                        console.error("Invalid JSON response:", response);
                        alert("An error occurred. Please try again.");
                    }
                }
            });
        }

        $("#profileForm").on("submit", function(e) {
            e.preventDefault();
            let formData = $(this).serialize() + '&session_token=' + sessionToken;
            $.ajax({
                url: 'php/profile.php',
                type: 'POST',
                data: formData,
                success: function(response) {
                    let res;
                    if (isValidJson(response)) {
                        res = JSON.parse(response);
                        if (res.status === 'success') {
                            alert("Profile updated successfully!");
                        } else {
                            alert(res.message || "Profile update failed. Please try again");
                        }
                    } else {
                        console.error("Invalid JSON response:", response);
                        alert("An error occurred. Please try again.");
                    }
                }
            });

        });
        
    }
});

// Helper function to check if a string is valid JSON
function isValidJson(str) {
    try {
        JSON.parse(str);
        return true;
    } catch (e) {
        return false;
    }
}
