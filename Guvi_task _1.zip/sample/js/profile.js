$(document).ready(function() {
    // Profile Page
    if (window.location.pathname.endsWith("profile.html")) {
        let sessionToken = localStorage.getItem('session_token');

        if (!sessionToken) {
            window.location.href = 'login.html';
        } else {
            $.ajax({
                url: 'php/getUserDetails.php',
                type: 'POST',
                data: { session_token: sessionToken },
                success: function(response) {
                    let res;
                    if (isValidJson(response)) {
                        res = JSON.parse(response);
                        if (res.status === 'success') {
                            let profile = res.profile;
                            $("#welcomeMessage").text(`Welcome to Guvi, ${profile.name}`);
                            $("#age").val(profile.age);
                            $("#dob").val(profile.dob);
                            $("#contact").val(profile.contact);
                        } else {
                            alert(res.message || "An error occurred. Please log in again.");
                            window.location.href = 'login.html';
                        }
                    } else {
                        console.error("Invalid JSON response:", response);
                        alert("An error occurred. Please try again.");
                    }
                }
            });
        }

        $("#profileForm").on("submit", function(e) {
            e.preventDefault();
            let formData = $(this).serialize() + '&session_token=' + sessionToken;
            $.ajax({
                url: 'php/profile.php',
                type: 'POST',
                data: formData,
                success: function(response) {
                    let res;
                    if (isValidJson(response)) {
                        res = JSON.parse(response);
                        if (res.status === 'success') {
                            alert("Profile updated successfully!");
                        } else {
                            alert(res.message || "Profile update failed. Please try again.");
                        }
                    } else {
                        console.error("Invalid JSON response:", response);
                        alert("An error occurred. Please try again.");
                    }
                }
            });
        });

        // Logout Button
        $("#logoutButton").on("click", function(e) {
            e.preventDefault(); // Prevent the default anchor behavior
            localStorage.removeItem('session_token');
            window.location.href = 'index.html';
        });
    }
});

// Helper function to check if a string is valid JSON
function isValidJson(str) {
    try {
        JSON.parse(str);
        return true;
    } catch (e) {
        return false;
    }
}
